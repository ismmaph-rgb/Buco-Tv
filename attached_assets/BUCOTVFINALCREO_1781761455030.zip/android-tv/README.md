# BUCO TV - Preparacion para APK Android TV

La aplicacion actual es 100% estatica. Para convertirla luego en APK se puede envolver con Capacitor, Android Studio o un Trusted Web Activity.

## Recomendacion para Android TV

1. Publicar primero la web en Netlify.
2. Crear el proyecto Android con Capacitor o TWA.
3. Activar soporte Leanback en el manifest nativo.
4. Mantener la navegacion por foco: la web ya soporta flechas, Enter/OK, Escape/Back.
5. Probar en emulador Android TV y en un dispositivo fisico.

## Capacitor opcional

```bash
npm init -y
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init "BUCO TV" "com.bucotv.app" --web-dir=.
npx cap add android
npx cap open android
```

En Android Studio, revisar:

- `android.software.leanback`
- orientacion landscape para TV
- iconos adaptativos
- permisos de internet
- pruebas con control remoto

## Estructura lista

- `manifest.webmanifest` para instalacion web/PWA.
- `scripts/app.js` con deteccion de modo TV y navegacion por flechas.
- `scripts/player.js` con reproductor HLS preparado para streams `.m3u8`.
- `data/channels.json` como unica fuente de canales.
