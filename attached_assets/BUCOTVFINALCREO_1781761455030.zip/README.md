# BUCO TV

BUCO TV es una plataforma IPTV web estatica, moderna y responsive, preparada para Netlify, Android TV, celulares Android y navegadores de Smart TV.

## Caracteristicas

- Interfaz oscura premium inspirada en plataformas de streaming.
- Inicio y seccion TV en Vivo.
- Canales cargados dinamicamente desde `data/channels.json`.
- Tarjetas horizontales tipo streaming, categorias y canal destacado.
- Reproductor integrado con HLS.js y fallback a reproduccion nativa.
- Pantalla de carga inicial.
- Pantalla de carga y error de stream.
- Modo pantalla completa.
- Modo TV con navegacion por flechas, Enter/OK, Escape/Back.
- Modo movil con controles tactiles y layout responsive.
- Sin backend obligatorio.

## Estructura

```text
/
├── index.html
├── manifest.webmanifest
├── netlify.toml
├── README.md
├── android-tv/
│   └── README.md
├── assets/
│   ├── banners/
│   ├── icons/
│   └── logo/
├── data/
│   └── channels.json
├── scripts/
│   ├── app.js
│   └── player.js
└── styles/
    └── main.css
```

## Cambiar el logo

No se encontro un logo cargado en la carpeta inicial, por eso el proyecto incluye un logo temporal en:

```text
assets/logo/buco-tv-logo.svg
```

Para usar el logo real, reemplaza ese archivo por el logo proporcionado, conservando el mismo nombre o actualizando las rutas en `index.html` y `manifest.webmanifest`.

## Agregar o quitar canales

Edita unicamente `data/channels.json`.

Formato:

```json
[
  {
    "id": 1,
    "name": "Canal 40",
    "category": "TV en Vivo",
    "logo": "assets/logo/canal40.png",
    "stream": "URL_DEL_STREAM",
    "featured": true
  }
]
```

Campos:

- `id`: identificador unico.
- `name`: nombre visible del canal.
- `category`: categoria o fila donde aparecera.
- `logo`: ruta del logo del canal.
- `stream`: URL HLS `.m3u8` o stream compatible con el navegador.
- `featured`: `true` para usarlo como destacado principal.

La aplicacion no tiene canales hardcodeados en JavaScript. Todo se renderiza desde `channels.json`.

## Probar en local

Como el navegador necesita cargar `channels.json`, conviene abrir el proyecto con un servidor local.

Con Python:

```bash
python -m http.server 4173
```

Luego abrir:

```text
http://localhost:4173
```

## Desplegar en Netlify

Opcion simple:

1. Entrar a Netlify.
2. Crear un nuevo sitio.
3. Arrastrar la carpeta del proyecto completa.
4. No usar comando de build.
5. Directorio de publicacion: `/` o `.`.

Opcion con Git:

- Build command: dejar vacio.
- Publish directory: `.`
- El archivo `netlify.toml` ya incluye cabeceras para assets y JSON.

## Preparacion para APK

La carpeta `android-tv/` incluye notas para convertir la web en APK con Capacitor, Android Studio o TWA. La interfaz ya esta preparada para control remoto con:

- flechas direccionales
- Enter/OK para seleccionar
- Escape/Back para cerrar el reproductor
- foco visible en botones y tarjetas

## Notas de streams

Los streams de ejemplo son URLs publicas de prueba. Para produccion, reemplazalos por tus URLs IPTV autorizadas en `data/channels.json`.
