(function () {
  "use strict";

  const CHANNELS_URL = "data/channels.json";
  const ALL_CATEGORIES = "Todos";

  const state = {
    channels: [],
    activeCategory: ALL_CATEGORIES,
    route: "home",
    featuredChannel: null,
    player: null,
    lastFocusedElement: null,
  };

  const dom = {};

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    cacheDom();
    setupPlayer();
    setupEvents();
    applyDeviceMode();

    try {
      state.channels = normalizeChannels(await loadChannels());
      state.featuredChannel = state.channels.find((channel) => channel.featured) || state.channels[0] || null;
      renderApp();
    } catch (error) {
      showLoadError(error);
    } finally {
      document.body.classList.add("is-ready");
    }
  }

  function cacheDom() {
    dom.app = document.getElementById("app");
    dom.hero = document.getElementById("hero");
    dom.heroEyebrow = document.getElementById("heroEyebrow");
    dom.heroTitle = document.getElementById("heroTitle");
    dom.heroDescription = document.getElementById("heroDescription");
    dom.heroPlay = document.getElementById("heroPlay");
    dom.jumpToLive = document.getElementById("jumpToLive");
    dom.categoryFilters = document.getElementById("categoryFilters");
    dom.contentSections = document.getElementById("contentSections");
    dom.emptyState = document.getElementById("emptyState");
    dom.cardTemplate = document.getElementById("channelCardTemplate");
    dom.navLinks = Array.from(document.querySelectorAll("[data-route]"));
    dom.tvModeToggle = document.getElementById("tvModeToggle");
    dom.playerShell = document.getElementById("playerShell");
  }

  function setupPlayer() {
    state.player = new window.BucoPlayer({
      shell: document.getElementById("playerShell"),
      video: document.getElementById("liveVideo"),
      videoFrame: document.getElementById("videoFrame"),
      loading: document.getElementById("playerLoading"),
      error: document.getElementById("playerError"),
      errorMessage: document.getElementById("playerErrorMessage"),
      title: document.getElementById("playerTitle"),
      logo: document.getElementById("playerLogo"),
      category: document.getElementById("playerCategory"),
      channelName: document.getElementById("playerChannelName"),
      fullscreenButton: document.getElementById("fullscreenButton"),
      retryButton: document.getElementById("retryButton"),
    });
  }

  function setupEvents() {
    dom.heroPlay.addEventListener("click", () => {
      if (state.featuredChannel) {
        openChannel(state.featuredChannel);
      }
    });

    dom.jumpToLive.addEventListener("click", () => {
      setRoute("live");
      scrollToContent();
    });

    dom.navLinks.forEach((link) => {
      link.addEventListener("click", () => setRoute(link.dataset.route));
    });

    dom.tvModeToggle.addEventListener("click", () => {
      const nextValue = !document.body.classList.contains("is-tv-mode");
      setTvMode(nextValue, true);
    });

    document.addEventListener("click", (event) => {
      const card = event.target.closest("[data-channel-id]");
      if (card) {
        const channel = state.channels.find((item) => String(item.id) === card.dataset.channelId);
        if (channel) {
          openChannel(channel);
        }
      }

      if (event.target.closest("[data-close-player]")) {
        closePlayer();
      }
    });

    document.addEventListener("keydown", handleKeyboardNavigation);
    window.addEventListener("resize", debounce(applyDeviceMode, 180));
  }

  async function loadChannels() {
    const response = await fetch(CHANNELS_URL, { cache: "no-store" });

    if (!response.ok) {
      throw new Error(`No se pudo cargar ${CHANNELS_URL}`);
    }

    const data = await response.json();

    if (!Array.isArray(data)) {
      throw new Error("channels.json debe ser un array de canales.");
    }

    return data;
  }

  function normalizeChannels(channels) {
    return channels
      .filter((channel) => channel && channel.id !== undefined)
      .map((channel) => ({
        id: channel.id,
        name: String(channel.name || "Canal sin nombre").trim(),
        category: String(channel.category || "TV en Vivo").trim(),
        logo: String(channel.logo || "assets/logo/buco-tv-logo.svg").trim(),
        stream: String(channel.stream || "").trim(),
        featured: Boolean(channel.featured),
      }));
  }

  function renderApp() {
    renderHero();
    renderFilters();
    renderSections();
    syncRouteUi();
    updateEmptyState();
  }

  function renderHero() {
    const channel = state.featuredChannel;

    if (!channel) {
      dom.heroPlay.disabled = true;
      return;
    }

    dom.heroEyebrow.textContent = channel.category || "TV en Vivo";
    dom.heroTitle.textContent = channel.name;
    dom.heroDescription.textContent =
      "Señal destacada de BUCO TV, lista para verse en vivo con una experiencia fluida y envolvente.";
    dom.heroPlay.disabled = false;
  }

  function renderFilters() {
    const categories = [ALL_CATEGORIES, ...getCategories()];
    const fragment = document.createDocumentFragment();

    categories.forEach((category) => {
      const button = document.createElement("button");
      button.className = "category-chip";
      button.type = "button";
      button.textContent = category;
      button.dataset.focusable = "";
      button.dataset.category = category;
      button.setAttribute("aria-pressed", String(category === state.activeCategory));

      if (category === state.activeCategory) {
        button.classList.add("is-active");
      }

      button.addEventListener("click", () => {
        state.activeCategory = category;
        renderFilters();
        renderSections();
        updateEmptyState();
      });

      fragment.appendChild(button);
    });

    dom.categoryFilters.replaceChildren(fragment);
  }

  function renderSections() {
    const fragment = document.createDocumentFragment();
    const visibleChannels = getVisibleChannels();

    if (state.activeCategory !== ALL_CATEGORIES) {
      fragment.appendChild(createSection(state.activeCategory, visibleChannels));
      dom.contentSections.replaceChildren(fragment);
      return;
    }

    if (state.route === "home") {
      const featured = state.channels.filter((channel) => channel.featured);
      if (featured.length) {
        fragment.appendChild(createSection("Destacados", featured));
      }
    }

    getCategories().forEach((category) => {
      const channels = visibleChannels.filter((channel) => channel.category === category);
      if (channels.length) {
        fragment.appendChild(createSection(category, channels));
      }
    });

    dom.contentSections.replaceChildren(fragment);
  }

  function createSection(title, channels) {
    const section = document.createElement("section");
    section.className = "channel-section";

    const header = document.createElement("div");
    header.className = "section-header";

    const heading = document.createElement("h2");
    heading.textContent = title;

    const count = document.createElement("span");
    count.textContent = `${channels.length} ${channels.length === 1 ? "canal" : "canales"}`;

    header.append(heading, count);

    const row = document.createElement("div");
    row.className = "channel-row";
    row.dataset.row = title;

    const rowFragment = document.createDocumentFragment();
    channels.forEach((channel) => rowFragment.appendChild(createCard(channel)));
    row.appendChild(rowFragment);

    section.append(header, row);
    return section;
  }

  function createCard(channel) {
    const card = dom.cardTemplate.content.firstElementChild.cloneNode(true);
    const image = card.querySelector(".channel-logo");

    card.dataset.channelId = channel.id;
    card.setAttribute("aria-label", `Reproducir ${channel.name}`);
    card.querySelector(".channel-name").textContent = channel.name;
    card.querySelector(".channel-category").textContent = channel.category;
    image.src = channel.logo;
    image.alt = `Logo de ${channel.name}`;
    image.addEventListener(
      "error",
      () => {
        image.src = "assets/logo/buco-tv-logo.svg";
      },
      { once: true },
    );

    return card;
  }

  function getVisibleChannels() {
    const channels = state.route === "live" ? state.channels : state.channels;

    if (state.activeCategory === ALL_CATEGORIES) {
      return channels;
    }

    return channels.filter((channel) => channel.category === state.activeCategory);
  }

  function getCategories() {
    return Array.from(new Set(state.channels.map((channel) => channel.category).filter(Boolean)));
  }

  function setRoute(route) {
    state.route = route;
    state.activeCategory = ALL_CATEGORIES;
    renderApp();

    if (route === "live") {
      scrollToContent();
    } else {
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  }

  function syncRouteUi() {
    dom.navLinks.forEach((link) => {
      const isActive = link.dataset.route === state.route;
      link.classList.toggle("is-active", isActive);
      link.setAttribute("aria-current", isActive ? "page" : "false");
    });
  }

  function updateEmptyState() {
    const hasChannels = getVisibleChannels().length > 0;
    dom.emptyState.hidden = hasChannels;
  }

  function showLoadError(error) {
    console.error(error);
    dom.heroPlay.disabled = true;
    dom.contentSections.replaceChildren();
    dom.emptyState.hidden = false;
    dom.emptyState.querySelector("h2").textContent = "No se pudieron cargar los canales";
    dom.emptyState.querySelector("p").textContent =
      "La grilla no está disponible en este momento. Intenta nuevamente más tarde.";
  }

  function openChannel(channel) {
    state.lastFocusedElement = document.activeElement;
    state.player.open(channel);
  }

  function closePlayer() {
    state.player.close();

    if (state.lastFocusedElement && typeof state.lastFocusedElement.focus === "function") {
      state.lastFocusedElement.focus({ preventScroll: true });
    }
  }

  function scrollToContent() {
    window.setTimeout(() => {
      dom.contentSections.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 40);
  }

  function applyDeviceMode() {
    const userAgent = navigator.userAgent || "";
    const tvLikeAgent = /Android TV|AFT|BRAVIA|SmartTV|SMART-TV|Tizen|Web0S|MiTV|Shield/i.test(userAgent);
    const coarsePointer = window.matchMedia("(pointer: coarse)").matches;
    const wideViewport = window.innerWidth >= 960;
    const storedTvMode = localStorage.getItem("buco-tv-mode");

    document.body.classList.toggle("is-mobile", window.innerWidth < 720 || (coarsePointer && !wideViewport));

    if (storedTvMode) {
      setTvMode(storedTvMode === "tv", false);
      return;
    }

    setTvMode(tvLikeAgent || (coarsePointer && wideViewport), false);
  }

  function setTvMode(enabled, persist) {
    document.body.classList.toggle("is-tv-mode", enabled);
    dom.tvModeToggle.setAttribute("aria-pressed", String(enabled));

    if (persist) {
      localStorage.setItem("buco-tv-mode", enabled ? "tv" : "touch");
    }
  }

  function handleKeyboardNavigation(event) {
    const key = event.key;
    const isArrow = ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(key);

    if (key === "Escape" || key === "Backspace") {
      if (!dom.playerShell.hidden) {
        event.preventDefault();
        closePlayer();
      }
      return;
    }

    if (key === "Enter" && document.activeElement === document.body) {
      const firstFocusable = getFocusableElements()[0];
      if (firstFocusable) {
        firstFocusable.focus();
      }
      return;
    }

    if (!isArrow) {
      return;
    }

    const activeElement = document.activeElement;

    if (!activeElement || !activeElement.matches("[data-focusable], .channel-card")) {
      return;
    }

    const nextElement = findNextFocusable(activeElement, key);

    if (nextElement) {
      event.preventDefault();
      nextElement.focus({ preventScroll: true });
      nextElement.scrollIntoView({ block: "nearest", inline: "nearest", behavior: "smooth" });
    }
  }

  function findNextFocusable(current, key) {
    const currentRect = current.getBoundingClientRect();
    const currentCenter = getCenter(currentRect);
    const candidates = getFocusableElements()
      .filter((element) => element !== current)
      .map((element) => ({
        element,
        rect: element.getBoundingClientRect(),
      }))
      .filter(({ rect }) => rect.width > 0 && rect.height > 0)
      .map((candidate) => ({
        ...candidate,
        center: getCenter(candidate.rect),
      }))
      .filter(({ center }) => {
        if (key === "ArrowRight") return center.x > currentCenter.x + 8;
        if (key === "ArrowLeft") return center.x < currentCenter.x - 8;
        if (key === "ArrowDown") return center.y > currentCenter.y + 8;
        return center.y < currentCenter.y - 8;
      });

    candidates.sort((a, b) => {
      const aScore = scoreCandidate(currentCenter, a.center, key);
      const bScore = scoreCandidate(currentCenter, b.center, key);
      return aScore - bScore;
    });

    return candidates[0] ? candidates[0].element : null;
  }

  function scoreCandidate(origin, candidate, key) {
    const dx = Math.abs(candidate.x - origin.x);
    const dy = Math.abs(candidate.y - origin.y);
    const primary = key === "ArrowLeft" || key === "ArrowRight" ? dx : dy;
    const secondary = key === "ArrowLeft" || key === "ArrowRight" ? dy : dx;
    return primary + secondary * 2.4;
  }

  function getCenter(rect) {
    return {
      x: rect.left + rect.width / 2,
      y: rect.top + rect.height / 2,
    };
  }

  function getFocusableElements() {
    return Array.from(document.querySelectorAll("[data-focusable], .channel-card")).filter((element) => {
      if (element.disabled || element.hidden) {
        return false;
      }

      const style = window.getComputedStyle(element);
      if (style.visibility === "hidden" || style.display === "none") {
        return false;
      }

      return Boolean(element.offsetParent || element === document.activeElement);
    });
  }

  function debounce(callback, wait) {
    let timeoutId;

    return (...args) => {
      window.clearTimeout(timeoutId);
      timeoutId = window.setTimeout(() => callback(...args), wait);
    };
  }
})();
