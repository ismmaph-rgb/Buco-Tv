(function () {
  "use strict";

  class BucoPlayer {
    constructor(options) {
      this.shell = options.shell;
      this.video = options.video;
      this.videoFrame = options.videoFrame;
      this.loading = options.loading;
      this.error = options.error;
      this.errorMessage = options.errorMessage;
      this.title = options.title;
      this.logo = options.logo;
      this.category = options.category;
      this.channelName = options.channelName;
      this.fullscreenButton = options.fullscreenButton;
      this.retryButton = options.retryButton;
      this.hls = null;
      this.currentChannel = null;

      this.retryButton.addEventListener("click", () => {
        if (this.currentChannel) {
          this.load(this.currentChannel);
        }
      });

      this.fullscreenButton.addEventListener("click", () => this.toggleFullscreen());
      this.video.addEventListener("playing", () => this.showVideo());
      this.video.addEventListener("canplay", () => this.showVideo());
      this.video.addEventListener("waiting", () => this.showLoading());
      this.video.addEventListener("error", () => {
        if (!this.hls) {
          this.showError("El navegador informó un error al abrir la señal.");
        }
      });
    }

    open(channel) {
      this.currentChannel = channel;
      this.updateMetadata(channel);
      this.shell.hidden = false;
      document.body.classList.add("player-open");
      this.load(channel);

      window.setTimeout(() => {
        this.video.focus({ preventScroll: true });
      }, 80);
    }

    close() {
      this.video.pause();
      this.destroyHls();
      this.video.removeAttribute("src");
      this.video.load();
      this.shell.hidden = true;
      document.body.classList.remove("player-open");
    }

    load(channel) {
      this.currentChannel = channel;
      this.showLoading();
      this.destroyHls();
      this.video.pause();
      this.video.removeAttribute("src");
      this.video.load();

      const streamUrl = String(channel.stream || "").trim();

      if (!streamUrl || streamUrl === "URL_DEL_STREAM") {
        this.showError("Este canal todavía no tiene una URL de stream configurada.");
        return;
      }

      const isHlsStream = /\.m3u8($|\?)/i.test(streamUrl);
      const canUseHlsJs = Boolean(window.Hls && window.Hls.isSupported() && isHlsStream);
      const canUseNativeHls = this.video.canPlayType("application/vnd.apple.mpegurl");

      if (canUseHlsJs) {
        this.hls = new window.Hls({
          enableWorker: true,
          lowLatencyMode: true,
          backBufferLength: 90,
          maxBufferLength: 30,
        });

        this.hls.loadSource(streamUrl);
        this.hls.attachMedia(this.video);

        this.hls.on(window.Hls.Events.MANIFEST_PARSED, () => this.safePlay());
        this.hls.on(window.Hls.Events.ERROR, (_event, data) => this.handleHlsError(data));
        return;
      }

      if (canUseNativeHls || !isHlsStream) {
        this.video.src = streamUrl;
        this.video.addEventListener("loadedmetadata", () => this.safePlay(), { once: true });
        return;
      }

      this.showError("Este navegador no pudo activar HLS.js ni reproducción HLS nativa.");
    }

    updateMetadata(channel) {
      this.title.textContent = channel.name;
      this.channelName.textContent = channel.name;
      this.category.textContent = channel.category || "TV en Vivo";
      this.logo.src = channel.logo || "assets/logo/buco-tv-logo.svg";
      this.logo.alt = channel.name ? `Logo de ${channel.name}` : "";
    }

    handleHlsError(data) {
      if (!data || !data.fatal) {
        return;
      }

      if (data.type === window.Hls.ErrorTypes.NETWORK_ERROR) {
        this.hls.startLoad();
        return;
      }

      if (data.type === window.Hls.ErrorTypes.MEDIA_ERROR) {
        this.hls.recoverMediaError();
        return;
      }

      this.showError("La señal no respondió o no es compatible en este momento.");
    }

    safePlay() {
      const playRequest = this.video.play();

      if (playRequest && typeof playRequest.catch === "function") {
        playRequest.catch(() => {
          this.showVideo();
        });
      }
    }

    showLoading() {
      this.loading.hidden = false;
      this.error.hidden = true;
    }

    showVideo() {
      this.loading.hidden = true;
      this.error.hidden = true;
    }

    showError(message) {
      this.loading.hidden = true;
      this.error.hidden = false;
      this.errorMessage.textContent = message;
    }

    async toggleFullscreen() {
      const target = this.videoFrame;

      if (document.fullscreenElement) {
        await document.exitFullscreen();
        return;
      }

      if (target.requestFullscreen) {
        await target.requestFullscreen();
        return;
      }

      if (target.webkitRequestFullscreen) {
        target.webkitRequestFullscreen();
      }
    }

    destroyHls() {
      if (this.hls) {
        this.hls.destroy();
        this.hls = null;
      }
    }
  }

  window.BucoPlayer = BucoPlayer;
})();
